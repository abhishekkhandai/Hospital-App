package com.bhadrak.hospitalapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;


import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import retrofit2.converter.scalars.ScalarsConverterFactory;


public class AccidentDetailsActivity extends AppCompatActivity implements PatientListAdapter.AccidentListClickListener {
    private RecyclerView request;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_response);

        request = findViewById(R.id.rc_request_list);
        request.setLayoutManager(new LinearLayoutManager(AccidentDetailsActivity.this, LinearLayoutManager.VERTICAL, false));

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.43.38/Hospital API/")
                .addConverterFactory(ScalarsConverterFactory.create()).build();


        ProgressDialog progressDialog = new ProgressDialog(AccidentDetailsActivity.this);
        progressDialog.show();

        Api api = retrofit.create(Api.class);
        api.getAccidentDetails().enqueue(new Callback<String>() {
            @Override
            public void onResponse(@NonNull Call<String> call, @NonNull Response<String> response) {
                Log.i("GetAccidentDetails", "Success");
                progressDialog.hide();
                ObjectMapper mapper = new ObjectMapper();
                String jsonResponse = "";

                try {
                    jsonResponse = mapper.writeValueAsString(response.body());
                } catch (Exception e) {
                    e.printStackTrace();
                }

                Log.i("Response", jsonResponse);
                modifyResponse(response.body());
            }

            @Override
            public void onFailure(@NonNull Call<String> call, @NonNull Throwable t) {
                Log.i("GetAccidentDetails", "Error");
                progressDialog.hide();
                Toast.makeText(AccidentDetailsActivity.this, "Error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void modifyResponse(String response) {
        ArrayList<Patient> accidentDetails = new ArrayList<>();
        try {
            JSONArray responseArray = new JSONArray(response);
            if (responseArray.length() > 0) {
                for (int i = 0; i < responseArray.length(); i++) {
                    Patient patient = Patient.parsPatient(responseArray.getJSONObject(i));
                    accidentDetails.add(patient);
                }
                setAdapter(accidentDetails);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setAdapter(ArrayList<Patient> accidentDetails) {
        PatientListAdapter adapter = new PatientListAdapter(AccidentDetailsActivity.this, accidentDetails);
        adapter.setListener(this);
        request.setAdapter(adapter);
    }


    @Override
    public void onAccidentDetailClicked(Patient patient) {
        Intent intent = new Intent(AccidentDetailsActivity.this, AmbulanceActivity.class);
        intent.putExtra("Patient", patient);
        startActivity(intent);
    }
}

