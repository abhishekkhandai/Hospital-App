package com.bhadrak.hospitalapp;

public class Constatns {
    public static String Send_Details_to_hospital="patient_status";
}
