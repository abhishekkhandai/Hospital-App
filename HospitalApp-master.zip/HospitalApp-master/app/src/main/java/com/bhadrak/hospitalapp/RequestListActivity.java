package com.bhadrak.hospitalapp;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class RequestListActivity extends AppCompatActivity implements Adapter.PatientListClickListner {

    DatabaseHelper helper;
    SQLiteDatabase database;
    private RecyclerView requestlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_list);
        RecyclerView requestlist = findViewById(R.id.rc_request_list);
        requestlist.setLayoutManager(new LinearLayoutManager(RequestListActivity.this, LinearLayout.VERTICAL,false));
        Bundle bundle=getIntent().getExtras();
        ArrayList<Patient>patients=new ArrayList<>();


        helper = new DatabaseHelper(RequestListActivity.this);
        database = helper.getWritableDatabase();
//        if (bundle!=null){
//            patients=(ArrayList<Patient>) bundle.getSerializable("Patient");
//
//
//        }

//        patients = helper.getAllData(database);
//
//        Adapter adapter = new Adapter(RequestListActivity.this,patients);
//        adapter.setListner(this);
//        requestlist.setAdapter(adapter);


    }



    @Override
    public void onPatientListClicked(Hospital hospital) {
        Intent intent=new Intent(RequestListActivity.this,SecondActivity.class);
        intent.putExtra("Patient",hospital);

        startActivity(intent);
    }
}
