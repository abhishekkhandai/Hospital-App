package com.bhadrak.hospitalapp;

import java.io.Serializable;

public class Hospital implements Serializable {
    String Hospitalname;
    String Doctorname,Ambulanceno,Driverno,Despatchtime,Arrivaltime,Fastaiddetails;

    public String getHospitalname() {
        return Hospitalname;
    }

    public void setHospitalname(String hospitalname) {
        Hospitalname = hospitalname;
    }

    public String getDoctorname() {
        return Doctorname;
    }

    public void setDoctorname(String doctorname) {
        Doctorname = doctorname;
    }

    public String getAmbulanceno() {
        return Ambulanceno;
    }

    public void setAmbulanceno(String ambulanceno) {
        Ambulanceno = ambulanceno;
    }

    public String getDriverno() {
        return Driverno;
    }

    public void setDriverno(String driverno) {
        Driverno = driverno;
    }

    public String getDespatchtime() {
        return Despatchtime;
    }

    public void setDespatchtime(String despatchtime) {
        Despatchtime = despatchtime;
    }

    public String getArrivaltime() {
        return Arrivaltime;
    }

    public void setArrivaltime(String arrivaltime) {
        Arrivaltime = arrivaltime;
    }

    public String getFastaiddetails() {
        return Fastaiddetails;
    }

    public void setFastaiddetails(String fastaiddetails) {
        Fastaiddetails = fastaiddetails;
    }
}
