package com.bhadrak.hospitalapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

  public class Adapter extends RecyclerView.Adapter<Adapter.RequestListHolder> {
    private Context context;
    private ArrayList<Hospital> hospitals;
    private PatientListClickListner listner;


    public Adapter(Context context,ArrayList<Hospital>hospitals){
        this.context=context;
        this.hospitals=hospitals;
    }
    public void setListner(PatientListClickListner listner){
        this.listner=listner;
    }
    @NonNull
    @Override
    public RequestListHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v= LayoutInflater.from(context).inflate(R.layout.cell_response,viewGroup,false);
        RequestListHolder holder=new RequestListHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RequestListHolder requestListHolder, int i) {
        final Hospital data=hospitals.get(i);
       requestListHolder.Hospital_name.setText(data.Hospitalname);
        requestListHolder.Doctor_name.setText(data.Doctorname);
        requestListHolder.Ambulance_no.setText(data.Ambulanceno);
        requestListHolder.Driver_no.setText(data.Driverno);
        requestListHolder.Despatched_time.setText(data.Despatchtime);
        requestListHolder.Arrival_time.setText(data.Arrivaltime);
        requestListHolder.Fastaid_details.setText(data.Fastaiddetails);


        requestListHolder.mlroot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listner!=null){
                    listner.onPatientListClicked(data);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return hospitals.size();
    }

    public interface PatientListClickListner {
        public void onPatientListClicked(Hospital hospital);
    }

    public  class RequestListHolder extends RecyclerView.ViewHolder{
        TextView Hospital_name,Doctor_name,Ambulance_no,Driver_no,Despatched_time,Arrival_time,Fastaid_details;
        LinearLayout mlroot;
        public RequestListHolder(View view) {
            super(view);
            Hospital_name=view.findViewById(R.id.hospital_name);
            Doctor_name=view.findViewById(R.id.doctor_name);
                Ambulance_no=view.findViewById(R.id.ambulance_no);
            Driver_no=view.findViewById(R.id.driver_no);
            Despatched_time=view.findViewById(R.id.despatch_time);
            Arrival_time=view.findViewById(R.id.arrival_time);
            Fastaid_details=view.findViewById(R.id.fastaid_details);
            mlroot=view.findViewById(R.id.mlroot);


        }



    }
}
