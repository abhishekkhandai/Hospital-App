package com.bhadrak.hospitalapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static String DATABASE_NAME = "HospitalData";
    public static String ID="id";
    public static String TABLE_NAME = "Patient";
    public static String hospital_name = "hospital name";
    public static String doctor_name = "doctor name";
    public static String ambulance_no = "ambulance no";
    public static String driver_no = "driver no";
    public static String despatch_time = "despatch time";
    public static String arrival_time = "arrival time";
    public static String fastaid_details = "fastaid details";
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(" CREATE TABLE " + TABLE_NAME + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                hospital_name + " TEXT NOT NULL," + doctor_name + " TEXT," +
                ambulance_no + " TEXT," + driver_no + " TEXT," + despatch_time + " INTEGER," +
                arrival_time + " INTEGER," + fastaid_details + " INTEGER);");
        

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertData(SQLiteDatabase db, Hospital hospital) {

        ContentValues contentValues = new ContentValues();
        contentValues.put(hospital_name, hospital.getHospitalname());
        contentValues.put(doctor_name, hospital.getDoctorname());
        contentValues.put(ambulance_no, hospital.getAmbulanceno());
        contentValues.put(driver_no, hospital.getDriverno());
        contentValues.put(despatch_time, hospital.getDespatchtime());
        contentValues.put(arrival_time, hospital.getArrivaltime());
        contentValues.put(fastaid_details, hospital.getFastaiddetails());



        db.insert(TABLE_NAME, null, contentValues);
    }

    public ArrayList<Hospital> getAllData(SQLiteDatabase db) {
        ArrayList<Hospital> hospitals = new ArrayList<>();


        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        if (cursor.moveToFirst()) {
            do {
                Hospital data = new Hospital();
                data.setHospitalname(cursor.getString(cursor.getColumnIndex(hospital_name)));
                data.setDoctorname(cursor.getString(cursor.getColumnIndex(doctor_name)));
                data.setAmbulanceno(cursor.getString(cursor.getColumnIndex(ambulance_no)));
                data.setDriverno(cursor.getString(cursor.getColumnIndex(driver_no)));
                data.setDespatchtime(cursor.getString(cursor.getColumnIndex(despatch_time)));
                data.setArrivaltime(cursor.getString(cursor.getColumnIndex(arrival_time)));
                data.setFastaiddetails(cursor.getString(cursor.getColumnIndex(fastaid_details)));

                hospitals.add(data);
            } while (cursor.moveToNext());
        }

        return hospitals;
    }
}




