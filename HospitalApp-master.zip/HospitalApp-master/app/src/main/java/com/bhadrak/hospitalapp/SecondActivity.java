package com.bhadrak.hospitalapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    TextView stv_location,stv_landmark,stv_district,stv_state,stv_pincode,stv_contactno,stv_noofpersonaffected;
    Patient patient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        stv_location=findViewById(R.id.tv_location);
        stv_landmark=findViewById(R.id.tv_landmark);
        stv_district=findViewById(R.id.et_district);
        stv_state=findViewById(R.id.tv_state);
        stv_pincode=findViewById(R.id.tv_pin_code);
        stv_contactno=findViewById(R.id.tv_contact_no);
        stv_noofpersonaffected=findViewById(R.id.tv_no_of_person_affected);

        Bundle bundle=getIntent().getExtras();

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(SecondActivity.this);
        final SharedPreferences.Editor editor = preferences.edit();

        if (bundle!=null){
            patient=(Patient)bundle.getSerializable("Patient");

        }
        if (patient!=null){
            stv_location.setText(patient.getLocation());
            stv_landmark.setText(patient.getLandmark());
            stv_district.setText(patient.getDistrict());
            stv_state.setText(patient.getState());
            stv_pincode.setText(patient.getPincode());
            stv_contactno.setText(patient.getContactno());
            stv_noofpersonaffected.setText(patient.getNo_of_persons_affected());
        }

    }


}
