package com.bhadrak.hospitalapp;

import java.io.Serializable;

public class Ambulance  {
    String hospitalname,doctorname,ambulanceno,despatchtime,arrivaltime,fastaid_details;
    String driverno;

    public String getHospitalname() {
        return hospitalname;
    }

    public void setHospitalname(String hospitalname) {
        this.hospitalname = hospitalname;
    }

    public String getDoctorname() {
        return doctorname;
    }

    public void setDoctorname(String doctorname) {
        this.doctorname = doctorname;
    }

    public String getAmbulanceno() {
        return ambulanceno;
    }

    public void setAmbulanceno(String ambulanceno) {
        this.ambulanceno = ambulanceno;
    }

    public String getDespatchtime() {
        return despatchtime;
    }

    public void setDespatchtime(String despatchtime) {
        this.despatchtime = despatchtime;
    }

    public String getArrivaltime() {
        return arrivaltime;
    }

    public void setArrivaltime(String arrivaltime) {
        this.arrivaltime = arrivaltime;
    }

    public String getFastaid_details() {
        return fastaid_details;
    }

    public void setFastaid_details(String fastaid_details) {
        this.fastaid_details = fastaid_details;
    }

    public String getDriverno() {
        return driverno;
    }

    public void setDriverno(String driverno) {
        this.driverno = driverno;
    }
}
