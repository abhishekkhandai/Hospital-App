package com.bhadrak.hospitalapp;

import retrofit2.Call;
import retrofit2.http.POST;

public interface Api {

    @POST("http://192.168.43.38/Hospital API/showaccidentapi.php/")
    Call<String> getAccidentDetails();


}
