package com.bhadrak.hospitalapp;

public class Constant {

    public static String BASE_URL = "http://192.168.43.38/";
}
