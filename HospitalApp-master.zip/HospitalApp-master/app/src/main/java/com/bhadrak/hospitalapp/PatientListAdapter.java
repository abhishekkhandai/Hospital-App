package com.bhadrak.hospitalapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class PatientListAdapter extends RecyclerView.Adapter<PatientListAdapter.ResponseListHolder> {
    private Context context;
    private ArrayList<Patient>accidentDetails;
    private AccidentListClickListener listener;
    public PatientListAdapter(Context context, ArrayList<Patient>accidentDetails){
        this.context=context;
        this.accidentDetails=accidentDetails;
    }

    public void setListener(AccidentListClickListener listener){
        this.listener = listener;
    }
    @NonNull
    @Override
    public PatientListAdapter.ResponseListHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(context).inflate(R.layout.cell_patient_details,viewGroup,false);
        ResponseListHolder holder=new ResponseListHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ResponseListHolder responseListHolder, int i) {
       final Patient data =accidentDetails.get(i);

        responseListHolder.accidentDetail.setText(data.getAccident());
        responseListHolder.date.setText(data.getDate());
        responseListHolder.location.setText(data.getLocation());
        responseListHolder.landmark.setText(data.getLandmark());
        responseListHolder.district.setText(data.getDistrict());
        responseListHolder.state.setText(data.getState());
        responseListHolder.pincode.setText(data.getPincode());
        responseListHolder.contactno.setText(data.getContactno());
        responseListHolder.no_of_persons.setText(data.getNo_of_persons_affected());

        responseListHolder.mlroot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null){
                    listener.onAccidentDetailClicked(data);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return accidentDetails.size();
    }

    public interface PatientListClickListner {
        void onPatientListClicked(Patient accidentDetail);
    }


    public class ResponseListHolder extends RecyclerView.ViewHolder {
        TextView accidentDetail, date, location, landmark, district, state, pincode, contactno, no_of_persons;
        LinearLayout mlroot;

        public ResponseListHolder(@NonNull View itemView) {
            super(itemView);
            accidentDetail =itemView.findViewById(R.id.tv_accident);
            date =itemView.findViewById(R.id.tv_date);
            location =itemView.findViewById(R.id.tv_location);
            landmark =itemView.findViewById(R.id.tv_landmark);
            district =itemView.findViewById(R.id.tv_district);
            state =itemView.findViewById(R.id.tv_state);
            pincode =itemView.findViewById(R.id.tv_pin_code);
            contactno = itemView.findViewById(R.id.tv_contact_no);
            no_of_persons = itemView.findViewById(R.id.tv_no_of_person_affected);
            mlroot=itemView.findViewById(R.id.mll_root);

        }
    }

    public interface AccidentListClickListener{
        void onAccidentDetailClicked(Patient patient);
    }
}
