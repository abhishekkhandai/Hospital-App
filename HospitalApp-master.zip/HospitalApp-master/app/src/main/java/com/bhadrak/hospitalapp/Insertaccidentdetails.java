package com.bhadrak.hospitalapp;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface Insertaccidentdetails {
    @FormUrlEncoded
    @POST("http://192.168.43.38/Hospital API/insertaccidentdetails.php/")
    Call<String> getAccidentDetails(@Field("hosname") String hospitalname,@Field("docname") String doctorname,@Field("regdnum") String  registrationumber,@Field("drivernum")String drivernumber,@Field("despatchedtime")String despatchedtime,@Field("atime")String arrivaltime,@Field("firstaid")String firstaid);



}
