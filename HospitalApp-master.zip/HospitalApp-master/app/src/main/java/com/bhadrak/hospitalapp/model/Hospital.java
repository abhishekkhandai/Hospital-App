package com.bhadrak.hospitalapp.model;

import com.bhadrak.hospitalapp.Patient;


import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class Hospital implements Serializable {

    String id;



    String accident;

    String date;
    String location;

    String landmark;

    String district;

    String state;

    String pincode;

    String contact_no;

    String no_of_person_affected;

 ArrayList<Patient>patients;


 public static Hospital parsUser(JSONObject jsonObject){
     Hospital user =new Hospital();
     user.id=jsonObject.optString("id");
     user.accident=jsonObject.optString("acc");
     user.date=jsonObject.optString("dt");
     user.location=jsonObject.optString("loc");
     user.landmark=jsonObject.optString("lan");
     user.district=jsonObject.optString("dis");
     user.state=jsonObject.optString("st");
     user.pincode=jsonObject.optString("pin");
     user.contact_no=jsonObject.optString("cnum");
     user.no_of_person_affected=jsonObject.optString("per");




     return user;
 }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccident() {
        return accident;
    }

    public void setAccident(String accident) {
        this.accident = accident;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getNo_of_person_affected() {
        return no_of_person_affected;
    }

    public void setNo_of_person_affected(String no_of_person_affected) {
        this.no_of_person_affected = no_of_person_affected;
    }
}
