package com.bhadrak.hospitalapp;

import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity  {
    private EditText location,landmark,district,state,pincode,contactno,noofpersonaffected;
    Button mbtnsubmit;
    DatabaseHelper databaseHelper;
    SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        location = findViewById(R.id.et_location);
        landmark = findViewById(R.id.et_landmark);
        pincode = findViewById(R.id.et_pincode);
        state = findViewById(R.id.et_state);
        noofpersonaffected = findViewById(R.id.et_no_of_person_affected);
        contactno = findViewById(R.id.et_contactno);
        district = findViewById(R.id.et_district);
        mbtnsubmit = findViewById(R.id.btn_submit);


        location.setText("");
        landmark.setText("");
        pincode.setText("");
        district.setText("");
        contactno.setText("");
        state.setText("");
        noofpersonaffected.setText("");


        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        final SharedPreferences.Editor editor = preferences.edit();
//        boolean isUserSubmit=preferences.getBoolean(Constatns.PREF_LOGIN_STATUS,false);


        databaseHelper = new DatabaseHelper(MainActivity.this);
        database = databaseHelper.getWritableDatabase();


        mbtnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String address = location.getText().toString();
                String place = landmark.getText().toString();
                String zipcode = pincode.getText().toString();
                String states = state.getText().toString();
                String personaffected = noofpersonaffected.getText().toString();
                String contact = contactno.getText().toString();
                String districts = district.getText().toString();


                Patient patient = new Patient();
                patient.setContactno(contact);
                patient.setDistrict(districts);
                patient.setLandmark(place);
                patient.setLocation(address);
                patient.setNo_of_persons_affected(personaffected);
                patient.setPincode(zipcode);
                patient.setState(states);


//                databaseHelper.insertData(database, patient);
//                ArrayList<Patient> patients = databaseHelper.getAllData(database);

//                Toast.makeText(MainActivity.this, "" + patients.size(), Toast.LENGTH_LONG).show();
                //Retrofit retrofit=new Retrofit.Builder().baseUrl("http://192.168.43.38/Hospital API/").addConverterFactory(ScalarsConverterFactory.create()).build();


                //Insertaccidentdetails chandu=retrofit.create(Insertaccidentdetails.class);
                //chandu.getAccidentDetails().enqueue(new Callback<String>() {
                // @Override
                ///    public void onResponse(Call<String> call, Response<String> response) {

//                        Log.i("SendHospitalDetails", "Success");
//
//                        ObjectMapper mapper = new ObjectMapper();
//                        String jsonResponse="";
//
//                        try{
//                            jsonResponse = mapper.writeValueAsString(response.body());
//                        }catch (Exception e){
//                            e.printStackTrace();
//                        }
//
//                        Log.i("Response", jsonResponse);
//                        modifyResponse(jsonResponse);
                //      }

                //        @Override
                //          public void onFailure(Call<String> call, Throwable t) {
                //                Log.i("SendHospitalDetails", "Error");

                //              }
                //            });


                //              Intent intent=new Intent(MainActivity.this,RequestListActivity.class);
//                intent.putExtra("Patient",patients);

                //  startActivity(intent);


                //}

                // private void modifyResponse(String response) {
                //ArrayList<Patient> patients = new ArrayList<>();
                //try {
                //JSONArray responseArray = new JSONArray(response);
                //if(responseArray.length() > 0){
                ///for (int i=0; i<responseArray.length(); i++){
                //   Patient patient = Patient.parsPatient(responseArray.getJSONObject(i));
                //     patients.add(patient);
                //   }
                //     setAdapter(patients);
                //   }
                // }catch (JSONException e){
                //   e.printStackTrace();
                ///  }
                //}

                ///private void setAdapter(ArrayList<Patient> patients) {
                //   Adapter adapter=new Adapter(MainActivity.this,patients);

                // }


            }


        });
    }}
