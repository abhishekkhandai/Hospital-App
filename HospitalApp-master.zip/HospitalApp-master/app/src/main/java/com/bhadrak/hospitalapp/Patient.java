package com.bhadrak.hospitalapp;


import org.json.JSONObject;

import java.io.Serializable;

public class Patient implements Serializable {
String id;
String accident;
String date;
String location;
String landmark;
String district;
String state;
String pincode;
String contactno;
String no_of_persons_affected;

    public static Patient parsPatient(JSONObject jsonObject) {
        Patient patient=new Patient();
        patient.id=jsonObject.optString("id");
        patient.accident=jsonObject.optString("acc");
        patient.date=jsonObject.optString("dt");
        patient.location=jsonObject.optString("loc");
        patient.landmark=jsonObject.optString("lan");
        patient.district=jsonObject.optString("dis");
        patient.state=jsonObject.optString("st");
        patient.pincode=jsonObject.optString("pin");
        patient.contactno=jsonObject.optString("cnum");
        patient.no_of_persons_affected=jsonObject.optString("per");


     return patient;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccident() {
        return accident;
    }

    public void setAccident(String accident) {
        this.accident = accident;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getContactno() {
        return contactno;
    }

    public void setContactno(String contactno) {
        this.contactno = contactno;
    }

    public String getNo_of_persons_affected() {
        return no_of_persons_affected;
    }

    public void setNo_of_persons_affected(String no_of_persons_affected) {
        this.no_of_persons_affected = no_of_persons_affected;
    }
}


