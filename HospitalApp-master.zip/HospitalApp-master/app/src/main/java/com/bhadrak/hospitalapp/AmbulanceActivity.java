package com.bhadrak.hospitalapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.scalars.ScalarsConverterFactory;

import static android.os.Build.VERSION_CODES.M;

public class AmbulanceActivity extends AppCompatActivity {

    EditText hospitalname,doctorname,ambulance_regd_no,driver_no,despatched_time,arrival_time,fastaid_details;

    Button send_ambulance;
    DatabaseHelper databaseHelper;
    SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ambulance);




        hospitalname=findViewById(R.id.hospital_name);
        doctorname=findViewById(R.id.doctor_name);
        ambulance_regd_no=findViewById(R.id.ambulance_no);
        driver_no=findViewById(R.id.driver_no);
        despatched_time=findViewById(R.id.despatch_time);
        arrival_time=findViewById(R.id.arrival_time);
        fastaid_details=findViewById(R.id.fastaid_details);

        send_ambulance = findViewById(R.id.send_ambulance);

        databaseHelper =new DatabaseHelper(AmbulanceActivity.this);
        database=databaseHelper.getWritableDatabase();





        send_ambulance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String hospital=hospitalname.getText().toString();
                String doctor=doctorname.getText().toString();
                String ambulance_no=ambulance_regd_no.getText().toString();
                String driver_contact_no=driver_no.getText().toString();
                String despatch=despatched_time.getText().toString();
                String arrived=arrival_time.getText().toString();
                String fastaid=fastaid_details.getText().toString();


                Hospital hospital1 = new Hospital();
                hospital1.setHospitalname(hospital);
                hospital1.setDoctorname(doctor);
                hospital1.setAmbulanceno(ambulance_no);
                hospital1.setDriverno(driver_contact_no);
                hospital1.setArrivaltime(arrived);
                hospital1.setDespatchtime(despatch);
                hospital1.setFastaiddetails(fastaid);

                databaseHelper.insertData(database,hospital1);
                ArrayList<Hospital>hospitals=databaseHelper.getAllData(database);


                hospitalname.setText("");
                doctorname.setText("");
                arrival_time.setText("");
                despatched_time.setText("");
                fastaid_details.setText("");
                driver_no.setText("");
                ambulance_regd_no.setText("");

                ProgressDialog progressDialog = new ProgressDialog(AmbulanceActivity.this);
                progressDialog.show();

                Retrofit retrofit=new Retrofit.Builder().baseUrl("http://192.168.43.38/Hospital API/").addConverterFactory(ScalarsConverterFactory.create()).build();

                Insertaccidentdetails chandu=retrofit.create(Insertaccidentdetails.class);
                chandu.getAccidentDetails(hospital1.getHospitalname(),hospital1.getDoctorname(),
                        hospital1.getAmbulanceno(),hospital1.getDriverno(),hospital1.getDespatchtime(),
                        hospital1.getArrivaltime(),hospital1.getFastaiddetails()).enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(Call<String> call, Response<String> response) {
                        Toast.makeText(AmbulanceActivity.this,"Data successffully sent",Toast.LENGTH_LONG).show();
                        finish();
                        progressDialog.hide();

                    }

                    @Override
                    public void onFailure(Call<String> call, Throwable t) {
                        progressDialog.hide();
                        Toast.makeText(AmbulanceActivity.this,"Error",Toast.LENGTH_LONG).show();

                    }
                });
            }
        });







    }



    }




