package com.bhadrak.hospitalapp;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Show_data extends AppCompatActivity {

    TextView hospitalname,doctorname,ambulanceno,driverno,despatchtime,arrivaltime,fastaiddetails;

    DatabaseHelper databaseHelper;
    SQLiteDatabase database;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data);

        hospitalname=findViewById(R.id.hospital_name);
        doctorname=findViewById(R.id.doctor_name);
        ambulanceno=findViewById(R.id.ambulance_no);
        driverno=findViewById(R.id.driver_no);
        despatchtime=findViewById(R.id.despatch_time);
        arrivaltime=findViewById(R.id.arrival_time);
        fastaiddetails=findViewById(R.id.fastaid_details);


        hospitalname.setText("");
        doctorname.setText("");
        ambulanceno.setText("");
        driverno.setText("");
        despatchtime.setText("");
        arrivaltime.setText("");
        fastaiddetails.setText("");

         databaseHelper= new DatabaseHelper(Show_data.this);
        database = databaseHelper.getWritableDatabase();





    }
}
