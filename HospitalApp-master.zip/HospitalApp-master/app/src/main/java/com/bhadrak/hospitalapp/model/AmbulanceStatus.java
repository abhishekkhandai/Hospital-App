package com.bhadrak.hospitalapp.model;

import java.io.Serializable;

public class AmbulanceStatus implements Serializable {




}
