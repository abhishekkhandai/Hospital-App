package com.bhadrak.hospitalapp;

import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class Accidentdetails implements Serializable {
    String id;
    boolean status;

    ArrayList<Patient> patients;

    public static Accidentdetails parsAccidentdetails(JSONObject jsonObject) {
        Accidentdetails accidentdetails = new Accidentdetails();
        accidentdetails.id = jsonObject.optString("id");
        accidentdetails.status = jsonObject.optBoolean("status");


        return accidentdetails;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public ArrayList<Patient> getPatients() {
        return patients;
    }

    public void setPatients(ArrayList<Patient> patients) {
        this.patients = patients;
    }
}
